# swagger_client.TraintricksApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**traintricks_post**](TraintricksApi.md#traintricks_post) | **POST** /traintricks | configuration for the training enhancements


# **traintricks_post**
> InlineResponseDefault4 traintricks_post(body=body)

configuration for the training enhancements

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.TraintricksApi()
body = swagger_client.Body9() # Body9 |  (optional)

try:
    # configuration for the training enhancements
    api_response = api_instance.traintricks_post(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling TraintricksApi->traintricks_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body9**](Body9.md)|  | [optional] 

### Return type

[**InlineResponseDefault4**](InlineResponseDefault4.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

