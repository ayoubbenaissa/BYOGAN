# InlineResponseDefault5

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**d_error** | **list[float]** | array containing the total error of D for each batch of the training iteration | [optional] 
**g_error** | **list[float]** | array containing the total error of G for each batch of the training iteration | [optional] 
**d_loss_real_min** | **list[float]** | array containing minimum error values procused by D for real data | [optional] 
**d_loss_real_mean** | **list[float]** | array containing mean error values procused by D for real data | [optional] 
**d_loss_real_max** | **list[float]** | array containing max error values procused by D for real data | [optional] 
**d_loss_fake_min** | **list[float]** | array containing minimum error values procused by D for generated data | [optional] 
**d_loss_fake_mean** | **list[float]** | array containing mean error values procused by D for generated data | [optional] 
**d_loss_fake_max** | **list[float]** | array containing max error values procused by D for generated data | [optional] 
**generated_bytes** | **str** | ascii decoded image containing generated samples with high KL | [optional] 
**worst_generated_bytes** | **str** | ascii decoded image containing generated samples with low KL | [optional] 
**real_bytes** | **str** | ascii decoded image containing real data samples | [optional] 
**real_2d** | **list[float]** | reduced real data to 2D | [optional] 
**fake_2d** | **list[float]** | reduced generated data to 2D | [optional] 
**real_3d** | **list[float]** | reduced real data to 3D | [optional] 
**fake_3d** | **list[float]** | reduced generated data to 3D | [optional] 
**kl_div** | **list[float]** | KL divergence values between real and generated data for each batch of the training iteration | [optional] 
**js_div** | **list[float]** | JS divergence values between real and generated data for each batch of the training iteration | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


