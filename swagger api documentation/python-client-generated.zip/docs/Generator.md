# Generator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | architecture of G | 
**drop_out** | **object** | array of drop-outs per hidden layer | [optional] 
**leaky_relu** | **object** |  | [optional] 
**n_layers** | **float** |  | [optional] 
**input_channels** | **float** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


