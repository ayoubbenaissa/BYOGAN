# swagger_client.DiscriminatoroptimizerApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**discriminatoroptimizer_post**](DiscriminatoroptimizerApi.md#discriminatoroptimizer_post) | **POST** /discriminatoroptimizer | discriminator optimizer configuration


# **discriminatoroptimizer_post**
> InlineResponseDefault2 discriminatoroptimizer_post(body=body)

discriminator optimizer configuration

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DiscriminatoroptimizerApi()
body = swagger_client.Body6() # Body6 |  (optional)

try:
    # discriminator optimizer configuration
    api_response = api_instance.discriminatoroptimizer_post(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DiscriminatoroptimizerApi->discriminatoroptimizer_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body6**](Body6.md)|  | [optional] 

### Return type

[**InlineResponseDefault2**](InlineResponseDefault2.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

