# swagger_client.GeneratorlossApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**generatorloss_post**](GeneratorlossApi.md#generatorloss_post) | **POST** /generatorloss | generator loss function configuration


# **generatorloss_post**
> InlineResponseDefault generatorloss_post(body=body)

generator loss function configuration

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.GeneratorlossApi()
body = swagger_client.Body4() # Body4 |  (optional)

try:
    # generator loss function configuration
    api_response = api_instance.generatorloss_post(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GeneratorlossApi->generatorloss_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body4**](Body4.md)|  | [optional] 

### Return type

[**InlineResponseDefault**](InlineResponseDefault.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

