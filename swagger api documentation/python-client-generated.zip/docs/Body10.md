# Body10

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**visualization_size** | **float** | number of images to display (Real and generated images) | [optional] 
**nb_batches** | **float** | number of batches per training iteration | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


