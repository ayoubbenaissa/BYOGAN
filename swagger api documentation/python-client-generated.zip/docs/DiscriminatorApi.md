# swagger_client.DiscriminatorApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**discriminator_post**](DiscriminatorApi.md#discriminator_post) | **POST** /discriminator | configure discriminator component


# **discriminator_post**
> CreatedDiscriminator discriminator_post(body)

configure discriminator component

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DiscriminatorApi()
body = swagger_client.Discriminator() # Discriminator | discriminator object to be created

try:
    # configure discriminator component
    api_response = api_instance.discriminator_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DiscriminatorApi->discriminator_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Discriminator**](Discriminator.md)| discriminator object to be created | 

### Return type

[**CreatedDiscriminator**](CreatedDiscriminator.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

