# Body9

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**flip** | **bool** | whether to apply label flipping | [optional] 
**smooth** | **bool** | whether to apply label smoothing | [optional] 
**apply_occasional_flip** | **bool** | whether to apply occasional label flipping | [optional] 
**occasional_flip** | **float** | in case of applying occasional label flipping, this property presents the probability with which the flipping operation will be used | [optional] 
**apply_feature_matching** | **bool** | whether to apply feature matching (used with SGD loss function) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


