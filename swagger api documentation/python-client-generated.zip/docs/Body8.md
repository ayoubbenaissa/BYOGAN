# Body8

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**noise_type** | **str** | distribution to be used for the Latent Vector (Uniform, Gaussian, Multivariate Gaussian) | [optional] 
**state** | **str** | state of the used latent vector (created or updated) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


