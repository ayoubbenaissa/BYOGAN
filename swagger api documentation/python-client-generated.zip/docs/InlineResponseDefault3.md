# InlineResponseDefault3

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **str** | distribution that will be used for the Latent Vector (Uniform, Gaussian, Multivariate Gaussian) | [optional] 
**message** | **str** | state of Latent Vector (created or updated) | [optional] 
**shape** | **list[float]** |  | [optional] 
**in_size** | **float** | this is basically the batch size | [optional] 
**out_size** | **float** | this is basically the input size for the Generator | [optional] 
**device** | **str** | this is basically the same device used for the Generator (cpu, gpu) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


