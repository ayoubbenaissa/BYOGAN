# swagger_client.GeneratorApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**generator_post**](GeneratorApi.md#generator_post) | **POST** /generator | configure generator component


# **generator_post**
> CreatedGenerator generator_post(body)

configure generator component

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.GeneratorApi()
body = swagger_client.Generator() # Generator | generator object to be created

try:
    # configure generator component
    api_response = api_instance.generator_post(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GeneratorApi->generator_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Generator**](Generator.md)| generator object to be created | 

### Return type

[**CreatedGenerator**](CreatedGenerator.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

