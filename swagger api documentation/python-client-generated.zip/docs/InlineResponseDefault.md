# InlineResponseDefault

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**loss** | **str** | loss function that will be used (BCE, MSE) | [optional] 
**response** | **str** | state of the loss function (created or updated) | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


