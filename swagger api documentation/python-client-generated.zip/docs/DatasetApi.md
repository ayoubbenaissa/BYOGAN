# swagger_client.DatasetApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**add_pet**](DatasetApi.md#add_pet) | **POST** /dataset | configure dataset component


# **add_pet**
> CreatedDataLoader add_pet(body)

configure dataset component

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.DatasetApi()
body = swagger_client.Dataset() # Dataset | Dataset/Dataloader object to be created

try:
    # configure dataset component
    api_response = api_instance.add_pet(body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling DatasetApi->add_pet: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Dataset**](Dataset.md)| Dataset/Dataloader object to be created | 

### Return type

[**CreatedDataLoader**](CreatedDataLoader.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

