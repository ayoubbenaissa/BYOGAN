# swagger_client.GeneratoroptimizerApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**generatoroptimizer_post**](GeneratoroptimizerApi.md#generatoroptimizer_post) | **POST** /generatoroptimizer | generator optimizer configuration


# **generatoroptimizer_post**
> InlineResponseDefault1 generatoroptimizer_post(body=body)

generator optimizer configuration

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.GeneratoroptimizerApi()
body = swagger_client.Body5() # Body5 |  (optional)

try:
    # generator optimizer configuration
    api_response = api_instance.generatoroptimizer_post(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling GeneratoroptimizerApi->generatoroptimizer_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body5**](Body5.md)|  | [optional] 

### Return type

[**InlineResponseDefault1**](InlineResponseDefault1.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

