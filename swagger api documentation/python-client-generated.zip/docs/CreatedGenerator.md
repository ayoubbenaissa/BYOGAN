# CreatedGenerator

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**message** | **str** |  | [optional] 
**model** | **object** | Generator element | [optional] 
**device** | **str** |  | [optional] 
**init** | **str** |  | [optional] 
**init_description** | **str** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


