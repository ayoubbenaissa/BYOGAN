# swagger_client.LatentvectorApi

All URIs are relative to *https://virtserver.swaggerhub.com/AyoubBenaissa/BYOGAN_api/1.0.0*

Method | HTTP request | Description
------------- | ------------- | -------------
[**latentvector_post**](LatentvectorApi.md#latentvector_post) | **POST** /latentvector | configuration for the latent vector


# **latentvector_post**
> InlineResponseDefault3 latentvector_post(body=body)

configuration for the latent vector

### Example
```python
from __future__ import print_function
import time
import swagger_client
from swagger_client.rest import ApiException
from pprint import pprint

# create an instance of the API class
api_instance = swagger_client.LatentvectorApi()
body = swagger_client.Body8() # Body8 |  (optional)

try:
    # configuration for the latent vector
    api_response = api_instance.latentvector_post(body=body)
    pprint(api_response)
except ApiException as e:
    print("Exception when calling LatentvectorApi->latentvector_post: %s\n" % e)
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **body** | [**Body8**](Body8.md)|  | [optional] 

### Return type

[**InlineResponseDefault3**](InlineResponseDefault3.md)

### Authorization

No authorization required

### HTTP request headers

 - **Content-Type**: application/json, application/xml
 - **Accept**: application/json, application/xml

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

